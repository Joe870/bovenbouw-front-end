tafelvan2 = [];
tafelvan4 = [];
tafelvan6 = [];
tafelvan8 = [];

document.write("<h1> tafel van 2 </h1>");
for(i=1;i<11;i++){
    nummer1 = i;
    nummer2 = 2;
    nummer = nummer1 * nummer2;
    tafelvan2.push(nummer);
    document.write(nummer1, "*", nummer2, "=", nummer, "<br>");
}

document.write("<h1> tafel van 4 </h1>");
for(i=1;i<11;i++){
    nummer1 = i;
    nummer2 = 4;
    nummer = nummer1 * nummer2;
    tafelvan4.push(nummer);
    document.write(nummer1, "*", nummer2, "=", nummer, "<br>");
}

document.write("<h1> tafel van 6 </h1>");
for(i=1;i<11;i++){
    nummer1 = i;
    nummer2 = 6;
    nummer = nummer1 * nummer2;
    tafelvan4.push(nummer);
    document.write(nummer1, "*", nummer2, "=", nummer, "<br>");
}


document.write("<h1> tafel van 8 </h1>");
for(i=1;i<11;i++){
    nummer1 = i;
    nummer2 = 8;
    nummer = nummer1 * nummer2;
    tafelvan4.push(nummer);
    document.write(nummer1, "*", nummer2, "=", nummer, "<br>");
}

